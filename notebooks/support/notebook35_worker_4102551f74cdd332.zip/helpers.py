# @title Load case-review helpers (run unchanged)
from pathlib import Path
import hashlib
import json
import re
import tempfile
import traceback
import textwrap
import warnings
from io import BytesIO
from urllib.parse import urlencode
from urllib.request import urlopen
import numpy as np
import pandas as pd
import xarray as xr
import h5py
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import matplotlib.patheffects as path_effects
from matplotlib.path import Path as MplPath
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import metpy.calc as mpcalc
from metpy.units import units
import earthaccess
from IPython.display import display, clear_output

DATE_COLUMNS = ['event_start', 'event_end', 'event_peak']
REVIEW_COLUMNS = ['case_label', 'case_notes']
# L annotations use the same persistent pressure/wind/vorticity screen as event flags.
SHOW_CYCLONE_CENTERS = True

VORTEX_LABEL_SCHEME = 'notebook35_vortex_screen_v3'

def vortex_classification(record):
    """Use completed event-screen results; legacy manual case labels are unrelated."""
    status = str(record.get("vortex_scan_status", record.get("status", "not_scanned"))).strip().lower()
    if status == "ambiguous":
        return "Vortex status ambiguous"
    if status in {"unavailable", "failed", "error"}:
        return "Vortex status unavailable"
    if status != "complete":
        return "Vortex not checked"
    value = record.get("vortex_detected")
    if isinstance(value, (bool, np.bool_)):
        detected = bool(value)
    elif isinstance(value, (int, float, np.integer, np.floating)) and pd.notna(value) and value in (0, 1):
        detected = bool(value)
    elif isinstance(value, str) and value.strip().lower() in {"true", "false", "0", "1"}:
        detected = value.strip().lower() in {"true", "1"}
    else:
        return "Vortex status unknown"
    return "Vortex" if detected else "Non-vortex"


def vortex_plot_label(record):
    """Use the positive association flag for the two labels shown on figures."""
    if vortex_classification(record) == "Vortex":
        return "Vortex-associated"
    return "Non-vortex-associated"


def atomic_csv(frame, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    frame.to_csv(temp, index=False)
    temp.replace(path)

def normalise_events(frame):
    frame = frame.copy()
    for column in DATE_COLUMNS:
        if column not in frame:
            raise ValueError(f'Catalog is missing {column}. Choose the merged event catalog.')
        frame[column] = pd.to_datetime(frame[column], utc=True, errors='raise').dt.tz_localize(None)
        if frame[column].isna().any():
            raise ValueError(f'Missing timestamps in {column}.')
    if (frame.event_end < frame.event_start).any():
        raise ValueError('Catalog contains an event ending before it starts.')
    frame['review_key'] = frame[DATE_COLUMNS].apply(
        lambda row: '|'.join(t.isoformat() for t in row), axis=1)
    if frame.review_key.duplicated().any():
        raise ValueError('Duplicate start/end/peak windows in catalog; resolve before reviewing.')
    frame = frame.sort_values('event_peak').reset_index(drop=True)
    numbers = pd.to_numeric(frame.get('event_number', pd.Series(index=frame.index, dtype=float)), errors='coerce')
    valid_numbers = (numbers.notna().all() and numbers.gt(0).all()
                     and numbers.eq(numbers.round()).all() and not numbers.duplicated().any())
    frame['event_number'] = numbers.astype(int) if valid_numbers else np.arange(1, len(frame)+1)
    span = (frame.event_end-frame.event_start)/pd.Timedelta(hours=1) + 1
    duration = pd.to_numeric(frame.get('duration_hours', span), errors='coerce')
    if 'episode_span_hours' in frame:
        duration = pd.to_numeric(frame.episode_span_hours, errors='coerce').fillna(duration)
    frame['event_duration_hours'] = duration.where(duration.gt(0)).fillna(span)
    return frame

def event_option_label(row):
    """Use full-inventory numbers, never the position in a filtered dropdown."""
    peak = pd.to_numeric(row.get('event_peak_D_1e5_s-1', np.nan), errors='coerce')
    if pd.isna(peak):
        peak = pd.to_numeric(row.get('event_peak_D_s-1', np.nan), errors='coerce') * 1e5
    value = f'{peak:.2f}×10⁻⁵ s⁻¹' if pd.notna(peak) else 'unavailable'
    flag = ' | ' + vortex_plot_label(row)
    return (f"Event {int(row.event_number)} | Start {row.event_start:%Y-%m-%d %H:%M} UTC | "
            f"{row.event_duration_hours:g} h | Peak D12 {value} @ {row.event_peak:%Y-%m-%d %H:%M} UTC"+flag)

def check_catalog_completeness(merged, raw_path):
    """Check that the saved merged inventory includes every saved detector fragment."""
    report = {'merged_events': len(merged), 'raw_events': None, 'uncovered_raw_events': None}
    if Path(raw_path).exists():
        raw = normalise_events(pd.read_csv(raw_path))
        uncovered = raw.apply(lambda row: not ((merged.event_start <= row.event_start)
                              & (merged.event_end >= row.event_end)).any(), axis=1)
        report.update(raw_events=len(raw), uncovered_raw_events=int(uncovered.sum()))
        if uncovered.any():
            first = raw.loc[uncovered].iloc[0]
            raise RuntimeError(f'The merged catalog is missing {int(uncovered.sum())} saved raw detector fragment(s), '
                f'including {first.event_start} UTC. Run Notebook 06 to rebuild the merged catalog from '
                f'{raw_path}, then click Refresh catalog. The older inventory was not substituted.')
    return report

def reconcile_reviews(catalog, historical, review_path):
    """Only exact event-window matches transfer; row positions are never used."""
    frame = catalog.copy()
    history_columns = [c for c in historical if c not in DATE_COLUMNS + ['review_key']
                       and (c.startswith('verified') or 'note' in c.lower()
                            or c.startswith('satellite') or c.startswith('cloud_band'))]
    history = historical[['review_key', *history_columns]].rename(
        columns={c: 'historical_' + c for c in history_columns})
    history['historical_review_exact_match'] = True
    frame = frame.drop(columns=[c for c in history if c != 'review_key' and c in frame])
    frame = frame.merge(history, on='review_key', how='left', validate='one_to_one')
    frame['historical_review_exact_match'] = frame.historical_review_exact_match.eq(True)
    for column in REVIEW_COLUMNS:
        frame[column] = ''
    if Path(review_path).exists():
        saved = pd.read_csv(review_path).fillna('')
        if 'review_key' in saved:
            saved = saved.drop_duplicates('review_key', keep='last').set_index('review_key')
            for column in REVIEW_COLUMNS:
                if column in saved:
                    frame[column] = frame.review_key.map(saved[column]).fillna('')
    return frame

def save_review(row, label, notes):
    fresh = pd.DataFrame([{**{c: row[c] for c in DATE_COLUMNS},
        'review_key': row.review_key, 'case_label': label, 'case_notes': notes}])
    old = pd.read_csv(REVIEW_PATH) if REVIEW_PATH.exists() else pd.DataFrame()
    combined = fresh if old.empty else pd.concat([old, fresh], ignore_index=True)
    atomic_csv(combined.drop_duplicates('review_key', keep='last'), REVIEW_PATH)

def window_bounds(hour, hours):
    hour = pd.Timestamp(hour)
    if hour != hour.floor('h'):
        raise ValueError('Map time must be an exact UTC hour; no silent nearest-time substitution.')
    if hours not in (1, 12):
        raise ValueError('Choose a 1-hour or 12-hour matched window.')
    return hour - pd.Timedelta(hours=hours-1), hour + pd.Timedelta(hours=1)

def cache_id(hour, hours):
    settings = {'hour': pd.Timestamp(hour).isoformat(), 'hours': hours,
        'domain': DOMAIN, 'imerg_product': IMERG_PRODUCT, 'version': IMERG_VERSION,
        'coverage': MIN_PIXEL_TEMPORAL_COVERAGE, 'schema': 1}
    return hashlib.sha256(json.dumps(settings, sort_keys=True).encode()).hexdigest()[:16]

def field_from_hdf(path):
    west, east, south, north = DOMAIN
    with h5py.File(path, 'r') as f:
        lat, lon = np.asarray(f['Grid/lat'][:]), np.asarray(f['Grid/lon'][:])
        ix = np.flatnonzero((lon >= west) & (lon <= east))
        iy = np.flatnonzero((lat >= south) & (lat <= north))
        if not len(ix) or not len(iy):
            raise ValueError('No IMERG cells in requested map domain.')
        name = next((n for n in ['Grid/precipitation', 'Grid/precipitationCal'] if n in f), None)
        if name is None:
            raise ValueError('Expected IMERG precipitation field is absent.')
        data = f[name]
        values = np.asarray(data[0, ix[0]:ix[-1]+1, iy[0]:iy[-1]+1], dtype=float).T
        fill = float(np.asarray(data.attrs.get('_FillValue', -9999.9)).ravel()[0])
        values[(values < 0) | np.isclose(values, fill)] = np.nan
    return xr.DataArray(values, dims=('latitude', 'longitude'),
        coords={'latitude': lat[iy], 'longitude': lon[ix]}, name='precipitation',
        attrs={'units': 'mm h-1', 'source_field': name})

def granule_time(name):
    match = re.search(r'\.(\d{8})-S(\d{6})-E\d{6}', str(name))
    if not match:
        raise ValueError(f'Unrecognized IMERG granule name: {name}')
    return pd.to_datetime(''.join(match.groups()), format='%Y%m%d%H%M%S')

def imerg_cache_path(timestamp):
    # A half-hour subset is independent of the requested averaging/total window.
    settings = {'domain': DOMAIN, 'product': IMERG_PRODUCT, 'version': IMERG_VERSION}
    identity = hashlib.sha256(json.dumps(settings, sort_keys=True).encode()).hexdigest()[:16]
    return CACHE_DIR / f'imerg_subset_{timestamp:%Y%m%dT%H%M}_{identity}.nc'

def reuse_legacy_imerg(timestamp, destination):
    """Reuse this notebook's old window-specific subsets when product/domain match."""
    west, east, south, north = DOMAIN
    for candidate in CACHE_DIR.glob(f'imerg_{timestamp:%Y%m%dT%H%M}_*.nc'):
        with xr.open_dataarray(candidate) as data:
            if data.attrs.get('product') != IMERG_PRODUCT or data.attrs.get('version') != IMERG_VERSION:
                continue
            edges = [float(data.longitude.min()), float(data.longitude.max()),
                     float(data.latitude.min()), float(data.latitude.max())]
            # IMERG grid centers lie no more than 0.1 degrees inside the subset bounds.
            if not (west-.0001 <= edges[0] <= west+.1001 and east-.1001 <= edges[1] <= east+.0001
                    and south-.0001 <= edges[2] <= south+.1001 and north-.1001 <= edges[3] <= north+.0001):
                continue
            field = data.load()
        temporary = destination.with_suffix('.tmp.nc')
        field.to_netcdf(temporary)
        temporary.replace(destination)
        return

def load_imerg(hour, hours):
    return load_imerg_interval(*window_bounds(hour, hours))

def load_imerg_interval(start, end):
    start, end = pd.Timestamp(start), pd.Timestamp(end)
    if start != start.floor('30min') or end != end.floor('30min') or end <= start:
        raise ValueError('IMERG requires a positive interval aligned to half-hour boundaries.')
    expected = pd.date_range(start, end, freq='30min', inclusive='left')
    paths = {t: imerg_cache_path(t) for t in expected}
    for timestamp, path in paths.items():
        if not path.exists():
            reuse_legacy_imerg(timestamp, path)
    missing = [t for t in expected if not paths[t].exists()]
    if missing:
        require_earthdata_auth(globals().get('auth'))
        print(f'IMERG: {len(missing)} half-hour maps need retrieval; existing subsets are reused.')
        results = earthaccess.search_data(short_name=IMERG_PRODUCT, version=IMERG_VERSION,
            temporal=(start.isoformat(), (end-pd.Timedelta(seconds=1)).isoformat()), count=-1)
        wanted = set(missing)
        selected = []
        for granule in results:
            native = granule['umm']['DataGranule']['Identifiers']
            names = [entry['Identifier'] for entry in native]
            timestamp = None
            for name in names:
                try:
                    timestamp = granule_time(name)
                    break
                except ValueError:
                    pass
            if timestamp in wanted:
                selected.append((timestamp, granule))
                wanted.remove(timestamp)
        if not selected and not any(path.exists() for path in paths.values()):
            raise RuntimeError(f'No {IMERG_PRODUCT} V{IMERG_VERSION} granules found for {start}–{end} UTC. '
                               'Check archive coverage and NASA login. Missing precipitation is not zero.')
        selected.sort(key=lambda item: item[0])
        completed = 0
        for position in range(0, len(selected), 4):
            batch = selected[position:position+4]
            # Only this notebook-created temporary directory is removed.
            with tempfile.TemporaryDirectory(prefix='jpcz_imerg_') as temporary:
                downloaded = earthaccess.download([granule for _, granule in batch],
                                                  local_path=temporary, threads=len(batch))
                if not downloaded:
                    raise RuntimeError('NASA download returned no file; check Earthdata authentication.')
                files = {granule_time(Path(file).name): file for file in downloaded}
                for timestamp, granule in batch:
                    if timestamp not in files:
                        raise RuntimeError(f'NASA download did not return requested interval {timestamp}.')
                    field = field_from_hdf(files[timestamp])
                    field.attrs.update(product=IMERG_PRODUCT, version=IMERG_VERSION,
                        granule=Path(files[timestamp]).name, start_utc=timestamp.isoformat())
                    temporary_nc = paths[timestamp].with_suffix('.tmp.nc')
                    field.to_netcdf(temporary_nc)
                    temporary_nc.replace(paths[timestamp])
                    completed += 1
                    print(f'  saved regional subset {completed}/{len(selected)}: {timestamp}', flush=True)
    fields = []
    for timestamp, path in paths.items():
        if path.exists():
            with xr.open_dataarray(path) as data:
                fields.append(data.load().expand_dims(time=[timestamp]))
    stack = xr.concat(fields, dim='time').sortby('time').reindex(time=expected)
    coverage = stack.notnull().sum('time') / len(expected)
    mean = stack.mean('time', skipna=True).where(coverage >= MIN_PIXEL_TEMPORAL_COVERAGE)
    # Each IMERG value is a mean rate in mm/h for a 30-minute interval.
    # Integrate all intervals; any missing interval masks the pixel's total.
    # Do not extrapolate the available mean across an incomplete window.
    accumulation = (stack.sum('time', skipna=False) * 0.5).rename('precipitation_accumulation')
    accumulation.attrs.update(units='mm', integration='sum(half-hourly rate * 0.5 h)',
        window_start_utc=start.isoformat(), window_end_exclusive_utc=end.isoformat(),
        missing_data_policy='mask pixels missing any requested half-hour')
    received = sum(path.exists() for path in paths.values())
    return mean, accumulation, {'imerg_received_halfhours': received, 'imerg_expected_halfhours': len(expected),
        'imerg_status': 'complete' if received == len(expected) else 'partial',
        'imerg_accumulation_units': 'mm',
        'imerg_accumulation_method': 'sum(half-hourly rate * 0.5 h); complete pixel coverage required',
        'imerg_product': IMERG_PRODUCT, 'imerg_version': IMERG_VERSION}

def load_era5(hour, hours):
    path = CACHE_DIR / f'era5_{cache_id(hour, hours)}.nc'
    if path.exists():
        with xr.open_dataset(path) as cached:
            result = cached.load()
        # Notebook 35 previously cached C=-D in displayed units. Restore the
        # original signed D exactly once, then persist the unambiguous schema.
        if 'divergence' not in result:
            if 'convergence' not in result:
                raise ValueError('ERA5 map cache has no divergence or known legacy convergence field.')
            result['divergence'] = -result['convergence']
            result = result.drop_vars('convergence')
            result.attrs.pop('convergence_units', None)
            result.attrs['divergence_units'] = '1e-5 s-1'
            result.attrs['plot_quantity'] = 'signed horizontal divergence D'
            temporary = path.with_suffix('.tmp.nc')
            result.to_netcdf(temporary)
            temporary.replace(path)
        return result
    global era5
    if 'era5' not in globals():
        era5 = xr.open_zarr(ERA5_STORE, chunks=None, storage_options={'token': 'anon'})
    start, end = window_bounds(hour, hours)
    expected = pd.date_range(start, end, freq='h', inclusive='left')
    print(f'Loading {len(expected)} ERA5 hour(s), one variable at a time...', flush=True)
    snap = read_review_era5_window(era5, expected,
        ('u_component_of_wind', 'v_component_of_wind', 'mean_sea_level_pressure'), DOMAIN)
    dx, dy = mpcalc.lat_lon_grid_deltas(snap.longitude.values, snap.latitude.values)
    u = snap.u_component_of_wind
    v = snap.v_component_of_wind
    divergence = mpcalc.divergence(u.mean('time').values * units('m/s'),
        v.mean('time').values * units('m/s'), dx=dx, dy=dy).magnitude
    zeta = mpcalc.vorticity(u.isel(time=-1).values * units('m/s'),
        v.isel(time=-1).values * units('m/s'), dx=dx, dy=dy).magnitude
    coords = {'latitude': snap.latitude, 'longitude': snap.longitude}
    result = xr.Dataset({
        'divergence': xr.DataArray(divergence * 1e5, dims=('latitude','longitude'), coords=coords),
        'vorticity': xr.DataArray(zeta * 1e5, dims=('latitude','longitude'), coords=coords),
        'u': u.isel(time=-1, drop=True), 'v': v.isel(time=-1, drop=True),
        'mslp': snap.mean_sea_level_pressure.isel(time=-1, drop=True) / 100,
    }, attrs={'end_hour_utc': pd.Timestamp(hour).isoformat(), 'mean_hours': hours,
               'divergence_units': '1e-5 s-1', 'vorticity_units': '1e-5 s-1',
               'plot_quantity': 'signed horizontal divergence D'})
    temporary = path.with_suffix('.tmp.nc')
    result.to_netcdf(temporary)
    temporary.replace(path)
    return result

def polygon_mean(field, vertices):
    lon, lat = np.meshgrid(field.longitude.values, field.latitude.values)
    mask = MplPath(vertices).contains_points(np.c_[lon.ravel(), lat.ravel()]).reshape(lon.shape)
    weight = np.cos(np.deg2rad(lat)) * mask * np.isfinite(field.values)
    if weight.sum() == 0:
        return np.nan
    return float(np.nansum(field.values * weight) / weight.sum())

def detect_mslp_lows(pressure_hpa, longitude, latitude, *, min_depth_hpa=.5,
                     min_separation_km=200, max_centers=3):
    """Locate resolved closed MSLP minima, independently for each hourly map.

    A light 3x3 binomial smoothing suppresses grid noise. Each candidate must be
    enclosed by a +0.5-hPa pressure rise within the available map: its connected
    sublevel basin must not reach an edge or missing data. This deliberately
    omits open troughs and lows whose closure lies outside the map. It is a map
    annotation, not a cyclone track or JPCZ/vortex classification.
    """
    pressure = np.asarray(pressure_hpa, dtype=float)
    lon, lat = np.asarray(longitude, dtype=float), np.asarray(latitude, dtype=float)
    if pressure.shape != (len(lat), len(lon)) or pressure.ndim != 2:
        raise ValueError('MSLP must be a latitude × longitude grid in hPa.')
    if min(pressure.shape) < 5 or not np.isfinite(pressure).any():
        return []
    if min_depth_hpa <= 0 or min_separation_km < 0 or max_centers < 1:
        raise ValueError('Use positive low depth/count and nonnegative separation.')
    kernel = np.array([[1,2,1], [2,4,2], [1,2,1]], dtype=float)/16
    patches = np.lib.stride_tricks.sliding_window_view(
        np.pad(pressure, 1, mode='edge'), (3,3))
    smooth = np.sum(patches*kernel, axis=(-2,-1))
    if not np.isfinite(smooth).any() or np.nanmax(smooth)-np.nanmin(smooth) < min_depth_hpa:
        return []
    neighbors = np.lib.stride_tricks.sliding_window_view(
        np.pad(np.where(np.isfinite(smooth), smooth, np.inf), 1,
               mode='constant', constant_values=np.inf), (3,3))
    candidates = np.isfinite(smooth) & (smooth <= neighbors.min(axis=(-2,-1))+1e-9)
    candidates[[0,-1], :] = False
    candidates[:, [0,-1]] = False
    indices = sorted(map(tuple, np.argwhere(candidates)), key=lambda ij: smooth[ij])
    centers, examined = [], set()
    ny, nx = pressure.shape
    for iy, ix in indices:
        if (iy, ix) in examined:
            continue
        threshold = smooth[iy, ix]+min_depth_hpa
        basin, stack, closed = set(), [(iy, ix)], True
        while stack:
            y, x = stack.pop()
            if (y,x) in basin:
                continue
            basin.add((y,x))
            if y in (0,ny-1) or x in (0,nx-1):
                closed = False
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    yy, xx = y+dy, x+dx
                    if not (0 <= yy < ny and 0 <= xx < nx):
                        continue
                    if not np.isfinite(smooth[yy,xx]):
                        closed = False
                    elif smooth[yy,xx] < threshold and (yy,xx) not in basin:
                        stack.append((yy,xx))
        examined.update(basin)
        if not closed:
            continue
        # One center for a flat minimum; place the glyph at its central grid cell.
        floor = [(y,x) for y,x in basin if abs(smooth[y,x]-smooth[iy,ix]) < 1e-9]
        mean_y, mean_x = np.mean(floor, axis=0)
        iy, ix = min(floor, key=lambda ij: (ij[0]-mean_y)**2+(ij[1]-mean_x)**2)
        west, east, south, north = DOMAIN
        if not (west < lon[ix] < east and south < lat[iy] < north):
            continue
        too_close = False
        for center in centers:
            phi1, phi2 = np.deg2rad([lat[iy], center['latitude']])
            dphi = phi1-phi2
            dlambda = np.deg2rad(lon[ix]-center['longitude'])
            distance = 2*6371*np.arcsin(np.sqrt(np.clip(
                np.sin(dphi/2)**2+np.cos(phi1)*np.cos(phi2)*np.sin(dlambda/2)**2, 0, 1)))
            too_close |= distance < min_separation_km
        if too_close:
            continue
        centers.append({'longitude': float(lon[ix]), 'latitude': float(lat[iy]),
            'mslp_hpa': float(pressure[iy,ix]), 'smoothed_mslp_hpa': float(smooth[iy,ix])})
        if len(centers) >= max_centers:
            break
    return centers

def cyclone_circulation_evidence(center, longitude, latitude, u, v, vorticity_1e5, valid_mask=None):
    """Conservative circulation screen, not a validated cyclone-type classifier.

    Require a full 100–250 km annulus, positive inner-disk mean vorticity, and
    counterclockwise tangential winds in all eight azimuth sectors after removing
    the annulus-mean steering wind. The weakest sector must retain at least 50%
    of the ring mean, to reject simple shear strips with little cross-flow.
    """
    lon, lat = np.meshgrid(np.asarray(longitude), np.asarray(latitude))
    u, v, zeta = [np.asarray(a, dtype=float) for a in (u, v, vorticity_1e5)]
    if any(a.shape != lon.shape for a in (u,v,zeta)):
        raise ValueError('Wind and vorticity grids must match the MSLP grid.')
    latitude0, longitude0 = center['latitude'], center['longitude']
    x = 6371*np.cos(np.deg2rad(latitude0))*np.deg2rad(lon-longitude0)
    y = 6371*np.deg2rad(lat-latitude0)
    radius = np.hypot(x,y)
    # A clipped annulus cannot establish circulation around a whole center.
    west, east = float(lon.min()), float(lon.max())
    south, north = float(lat.min()), float(lat.max())
    edge_km = min(6371*np.cos(np.deg2rad(latitude0))*np.deg2rad(
        min(longitude0-west,east-longitude0)),
        6371*np.deg2rad(min(latitude0-south,north-latitude0)))
    evidence = {'passes_circulation_screen': False, 'annulus_inner_km':100,
                'annulus_outer_km':250, 'full_annulus_on_map': bool(edge_km >= 250)}
    if edge_km < 250:
        evidence['rejection_reason'] = 'Incomplete wind annulus at map edge'
        return evidence
    ring = (radius >= 100) & (radius <= 250)
    inner = radius <= 150
    valid = np.isfinite(u) & np.isfinite(v) & np.isfinite(zeta)
    if valid_mask is not None:
        valid &= np.asarray(valid_mask, dtype=bool)
    if (not ring.any() or not inner.any() or
            np.mean(valid[ring]) < .8 or np.mean(valid[inner]) < .8):
        evidence['rejection_reason'] = 'Missing wind/vorticity data'
        return evidence
    original_ring = ring.copy()
    ring &= valid
    inner &= valid
    weights = np.cos(np.deg2rad(lat))
    mean_u = np.average(u[ring], weights=weights[ring])
    mean_v = np.average(v[ring], weights=weights[ring])
    tangential = (-(u-mean_u)*y+(v-mean_v)*x)/np.where(radius>0,radius,1)
    angle = np.mod(np.arctan2(y,x)+np.pi/8,2*np.pi)
    sectors = np.floor(angle/(np.pi/4)).astype(int)
    sector_means = []
    for sector in range(8):
        mask = ring & (sectors == sector)
        total = (original_ring & (sectors == sector)).sum()
        if mask.sum() < 3 or mask.sum()/max(1,total) < .6:
            evidence['rejection_reason'] = 'Insufficient wind samples around center'
            return evidence
        sector_means.append(float(np.average(tangential[mask], weights=weights[mask])))
    mean_tangent = float(np.mean(sector_means))
    mean_zeta = float(np.average(zeta[inner], weights=weights[inner]))
    positive_fraction = float(np.average(zeta[inner]>0, weights=weights[inner]))
    sector_threshold = max(.5, .5*mean_tangent)
    passes = (mean_tangent >= 2 and min(sector_means) >= sector_threshold
              and mean_zeta >= 1 and positive_fraction >= .6)
    evidence.update(passes_circulation_screen=bool(passes),
        mean_tangential_wind_ms=mean_tangent, sector_tangential_winds_ms=sector_means,
        inner_mean_vorticity_1e5_s_1=mean_zeta, inner_positive_vorticity_fraction=positive_fraction,
        steering_u_ms=float(mean_u), steering_v_ms=float(mean_v),
        rejection_reason='' if passes else 'Insufficient coherent cyclonic circulation/vorticity')
    return evidence

def detect_cyclone_centers(ds):
    candidates = detect_mslp_lows(ds.mslp.transpose('latitude','longitude').values,
        ds.longitude.values, ds.latitude.values, max_centers=100)
    accepted, assessed = [], []
    for center in candidates:
        evidence = cyclone_circulation_evidence(center, ds.longitude.values, ds.latitude.values,
            ds.u.transpose('latitude','longitude').values, ds.v.transpose('latitude','longitude').values,
            ds.vorticity.transpose('latitude','longitude').values)
        assessed.append(dict(center, **evidence))
        if evidence['passes_circulation_screen']:
            accepted.append(dict(center, **evidence))
    return accepted[:3], assessed

def annotate_mslp_lows(ax, ds, metadata):
    if not SHOW_CYCLONE_CENTERS:
        metadata.update(mslp_low_centers='[]', mslp_low_center_count=0,
            mslp_low_candidate_evidence='[]',
            mslp_low_center_time_utc=pd.Timestamp(metadata['view_hour_utc']).isoformat(),
            mslp_low_center_status='disabled_pending_cyclone_validation',
            mslp_low_center_method='Disabled: automatic cyclone identification has not been validated')
        return []
    # Never fall back to the previous pressure-minimum-only labels.
    centers = json.loads(metadata.get('vortex_map_centers', '[]'))
    metadata.update(mslp_low_centers=json.dumps(centers), mslp_low_center_count=len(centers),
        mslp_low_center_status=metadata.get('vortex_map_status', 'not_scanned'),
        mslp_low_center_time_utc=pd.Timestamp(metadata['view_hour_utc']).isoformat(),
        mslp_low_center_method='Persistent pressure/wind/vorticity screen; land centers allowed; see vortex_screen_settings')
    for center in centers:
        ax.text(center['longitude'], center['latitude'], 'L',
            transform=ccrs.PlateCarree(), ha='center', va='center',
            fontsize=14, fontweight='bold', color='#153d72', zorder=15, clip_on=True,
            path_effects=[path_effects.withStroke(linewidth=2.5, foreground='white')])
    return centers

def satellite_defaults(hour):
    # Over Japan, daytime MODIS passes fall on the same UTC and JST date.
    # A nighttime UTC peak may belong to the following Japanese calendar day.
    return (pd.Timestamp(hour) + pd.Timedelta(hours=9)).normalize()

def validate_satellite_image(image):
    """GIBS can return a successful PNG containing only opaque black fill."""
    if image.ndim != 3 or image.shape[-1] not in (3, 4):
        raise RuntimeError('NASA returned an invalid satellite image.')
    scale = 255.0 if np.issubdtype(image.dtype, np.integer) else 1.0
    rgb = image[..., :3].astype(float) / scale
    visible = np.isfinite(rgb).all(axis=-1) & (rgb.max(axis=-1) > 1/255)
    if image.shape[-1] == 4:
        visible &= image[..., 3] > 0
    if not visible.any():
        raise RuntimeError('NASA returned a blank/black no-data image for this platform, date and region.')
    return float(visible.mean())

def load_visible_satellite(hour, platform='Terra', day_offset=0, composite='TrueColor'):
    """Fetch a historical visible daytime mosaic, never an invented peak-hour image."""
    if platform not in ('Terra', 'Aqua') or day_offset not in (-1, 0, 1):
        raise ValueError('Choose MODIS Terra/Aqua and a satellite day offset of -1, 0, or +1.')
    date = satellite_defaults(hour) + pd.Timedelta(days=day_offset)
    if composite not in ('TrueColor', 'Bands721'):
        raise ValueError('Choose TrueColor or Bands721 for historical MODIS imagery.')
    layer = f'MODIS_{platform}_CorrectedReflectance_{composite}'
    info = {'satellite_platform': f'MODIS {platform}', 'satellite_layer': layer,
        'satellite_mosaic_date_utc': date.strftime('%Y-%m-%d'),
        'satellite_day_offset': day_offset,
        'satellite_composite': composite,
        'satellite_time_basis': 'daily daytime mosaic; individual overpass time not resolved',
        'satellite_status': 'unavailable'}
    first_date = pd.Timestamp('2000-02-24' if platform == 'Terra' else '2002-07-03')
    if date < first_date:
        info['satellite_error'] = f'{platform} true-color imagery predates archive availability.'
        return None, info
    west, east, south, north = DOMAIN
    settings = {'date': str(date.date()), 'layer': layer, 'domain': DOMAIN, 'schema': 1}
    digest = hashlib.sha256(json.dumps(settings, sort_keys=True).encode()).hexdigest()[:16]
    path = CACHE_DIR / f'visible_{platform}_{composite}_{date:%Y%m%d}_{digest}.png'
    params = {'service': 'WMS', 'request': 'GetMap', 'version': '1.1.1',
        'layers': layer, 'styles': '', 'format': 'image/png', 'transparent': 'TRUE',
        'width': 1200, 'height': 840, 'srs': 'EPSG:4326',
        'bbox': f'{west},{south},{east},{north}', 'time': date.strftime('%Y-%m-%d')}
    url = 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi?' + urlencode(params)
    info['satellite_request_url'] = url
    try:
        image = None
        if path.exists():
            try:
                image = plt.imread(path)
                validate_satellite_image(image)
            except Exception:
                # These are disposable image caches, never user data or labels.
                path.unlink(missing_ok=True)
                image = None
        if image is None:
            with urlopen(url, timeout=40) as response:
                payload = response.read()
            if not payload.startswith(b'\x89PNG\r\n\x1a\n'):
                raise RuntimeError('NASA returned a service response instead of a PNG image.')
            image = plt.imread(BytesIO(payload), format='png')
            validate_satellite_image(image)  # Never cache a no-data response.
            temporary = path.with_suffix('.tmp.png')
            temporary.write_bytes(payload)
            temporary.replace(path)
        info['satellite_nonblank_fraction'] = validate_satellite_image(image)
        info['satellite_status'] = 'available_daily_mosaic'
        return image, info
    except Exception as error:
        info['satellite_error'] = f'{type(error).__name__}: {error}'
        print('Visible satellite:', info['satellite_error'])
        return None, info

def load_satellite_pair(hour, platform='Auto', day_offset=0):
    """Auto tries Terra then Aqua on the SAME requested date, never another day."""
    if platform not in ('Auto', 'Terra', 'Aqua'):
        raise ValueError('Choose Auto, Terra, or Aqua for satellite imagery.')
    attempts, best = [], None
    for candidate in (('Terra', 'Aqua') if platform == 'Auto' else (platform,)):
        image, info = load_visible_satellite(hour, candidate, day_offset, 'TrueColor')
        cloud, cloud_info = load_visible_satellite(hour, candidate, day_offset, 'Bands721')
        pair = (image, info, cloud, cloud_info)
        if best is None or sum(x is not None for x in (image, cloud)) > sum(
                x is not None for x in (best[0], best[2])):
            best = pair
        attempts.append({'platform': candidate, 'true_color_status': info['satellite_status'],
            'cloud_rgb_status': cloud_info['satellite_status'],
            'true_color_error': info.get('satellite_error', ''),
            'cloud_rgb_error': cloud_info.get('satellite_error', '')})
        if image is not None and cloud is not None:
            best = pair
            break
    image, info, cloud, cloud_info = best
    info['satellite_requested_platform'] = platform
    info['satellite_attempts'] = json.dumps(attempts)
    info['satellite_selection_note'] = (
        f"Auto used {info['satellite_platform']}; Terra imagery was unavailable/blank for this date."
        if platform == 'Auto' and info['satellite_platform'] == 'MODIS Aqua' else '')
    return image, info, cloud, cloud_info

def accumulation_bounds(row, hour, hours, mode):
    start, end = window_bounds(hour, hours)
    if mode == 'event_start':
        start = pd.Timestamp(row.event_start)
    elif mode != 'window':
        raise ValueError('Choose running accumulation from event start or selected window only.')
    return start, end

def get_case(row, hours=1, offset=0, label=None, satellite_platform='Auto', satellite_day_offset=0,
             accumulation_mode='event_start'):
    hour = pd.Timestamp(row.event_peak) + pd.Timedelta(hours=offset)
    accumulation_start, accumulation_end = accumulation_bounds(row, hour, hours, accumulation_mode)
    dynamics = load_era5(hour, hours)
    precipitation, accumulation, imerg_info = None, None, {}
    try:
        precipitation, accumulation, imerg_info = load_imerg(hour, hours)
    except Exception as error:
        if isinstance(error, MemoryError) or getattr(error, 'requires_earthdata_login', False):
            raise
        # Dynamics remain reviewable; missing precipitation is displayed explicitly.
        imerg_info = {'imerg_status': 'unavailable', 'imerg_error': f'{type(error).__name__}: {error}'}
        print(imerg_info['imerg_error'])
    metadata = {c: row[c] for c in DATE_COLUMNS}
    start, end = window_bounds(hour, hours)
    metadata.update(review_key=row.review_key, view_hour_utc=hour, window_start_utc=start,
        window_end_exclusive_utc=end, hours=hours, offset_hours=offset,
        legacy_manual_label=label or row.get('case_label', ''), **imerg_info)
    metadata.update(event_number=row.get('event_number', np.nan),
                    event_duration_hours=row.get('event_duration_hours', np.nan))
    try:
        metadata.update(vortex_case_metadata(row, hour))
    except Exception as error:
        if isinstance(error, MemoryError) or getattr(error, 'requires_earthdata_login', False):
            raise
        # A failed auxiliary screen must not prevent the existing weather maps.
        metadata.update(vortex_scan_status=row.get('vortex_scan_status', 'unavailable'),
            vortex_detected=row.get('vortex_detected'),
            vortex_map_centers='[]',vortex_map_status='unavailable',
            vortex_screen_error=f'{type(error).__name__}: {error}')
        print('Vortex screen unavailable; maps remain usable:',metadata['vortex_screen_error'])
    metadata.update(label=vortex_plot_label(metadata), label_scheme=VORTEX_LABEL_SCHEME)
    comparison = re.match(r'^Case ([AB]):', str(label or ''))
    metadata['comparison_slot'] = comparison.group(1) if comparison else ''
    accumulation_status = imerg_info.get('imerg_status', 'unavailable')
    if accumulation_mode == 'event_start':
        accumulation = None
        accumulation_status = 'not_started' if accumulation_end <= accumulation_start else 'unavailable'
        if accumulation_end > accumulation_start:
            print(f'Running IMERG total: {accumulation_start} to {accumulation_end} UTC', flush=True)
            try:
                _, accumulation, total_info = load_imerg_interval(accumulation_start, accumulation_end)
                accumulation_status = total_info['imerg_status']
                metadata.update(accumulation_received_halfhours=total_info['imerg_received_halfhours'],
                    accumulation_expected_halfhours=total_info['imerg_expected_halfhours'])
            except Exception as error:
                if isinstance(error, MemoryError) or getattr(error, 'requires_earthdata_login', False):
                    raise
                metadata['accumulation_error'] = f'{type(error).__name__}: {error}'
                print('Running total unavailable:', metadata['accumulation_error'])
    metadata.update(accumulation_mode=accumulation_mode, accumulation_status=accumulation_status,
        accumulation_start_utc=accumulation_start, accumulation_end_exclusive_utc=accumulation_end,
        accumulation_hours=max(0, (accumulation_end-accumulation_start)/pd.Timedelta(hours=1)))
    satellite_image, satellite_info, cloud_image, cloud_info = load_satellite_pair(
        hour, platform=satellite_platform, day_offset=satellite_day_offset)
    metadata.update(satellite_info)
    metadata.update({'cloud_rgb_'+key: value for key,value in cloud_info.items()})
    for name, vertices in POLYGONS.items():
        key = name.lower().replace(' ', '_')
        metadata[key+'_divergence_1e5_s-1'] = polygon_mean(dynamics.divergence, vertices)
        metadata[key+'_imerg_rate_mm_hr'] = (polygon_mean(precipitation, vertices)
                                            if precipitation is not None else np.nan)
        metadata[key+'_imerg_accumulation_mm'] = (polygon_mean(accumulation, vertices)
                                                if accumulation is not None else np.nan)
    return {'row': row.copy(), 'dynamics': dynamics, 'precipitation': precipitation,
            'precipitation_accumulation': accumulation,
            'satellite_image': satellite_image, 'cloud_rgb_image': cloud_image, 'metadata': metadata}

PRECIP_LEVELS = [0, .1, .25, .5, 1, 2, 4, 8, 16, 32]
ACCUM_LEVELS = [0, .1, .25, .5, 1, 2, 4, 8, 16, 32, 64, 128]
DIV_LEVELS = [-20, -15, -10, -5, -2, 0, 2, 5, 10, 15, 20]
VORT_LEVELS = [-30, -20, -10, -5, -2, 0, 2, 5, 10, 20, 30]

def decorate(ax):
    ax.set_extent(DOMAIN, crs=ccrs.PlateCarree())
    ax.add_feature(cfeature.LAND.with_scale('50m'), facecolor='.93', zorder=0)
    ax.coastlines(resolution='50m', linewidth=.65)
    ax.add_feature(cfeature.BORDERS.with_scale('50m'), linewidth=.35)
    ax.gridlines(draw_labels={'bottom':'x', 'left':'y'}, linewidth=.3, alpha=.4)
    for i, (name, vertices) in enumerate(POLYGONS.items()):
        points = np.asarray(vertices + [vertices[0]])
        ax.plot(points[:,0], points[:,1], transform=ccrs.PlateCarree(),
                color='black' if i == 0 else '#9c179e', linestyle='-' if i == 0 else '--',
                linewidth=1.6, label=name, zorder=8)

def plot_cases(cases, stem=None, *, show=True):
    # Keep rate/divergence/circulation above accumulation and both satellites.
    fig = plt.figure(figsize=(18, 10.5*len(cases)), layout='constrained')
    grid = fig.add_gridspec(2*len(cases), 3)
    axes = []
    for r in range(len(cases)):
        top = [fig.add_subplot(grid[2*r, c], projection=ccrs.PlateCarree()) for c in range(3)]
        bottom = [fig.add_subplot(grid[2*r+1, c], projection=ccrs.PlateCarree()) for c in range(3)]
        axes.append(top+bottom)
    axes = np.asarray(axes, dtype=object)
    for r, case in enumerate(cases):
        meta, ds = case['metadata'], case['dynamics']
        meta.update(label=vortex_plot_label(meta), label_scheme=VORTEX_LABEL_SCHEME)
        prefix = f"Case {meta['comparison_slot']} | " if meta.get('comparison_slot') else ''
        number = f" | Event {int(meta['event_number'])}" if pd.notna(meta.get('event_number')) else ''
        header = prefix + meta['label'] + number + f"\n{meta['view_hour_utc']:%Y-%m-%d %H:%M} UTC"
        offset = int(meta.get('offset_hours', 0))
        header += f' | offset {offset:+d} h from peak'
        fields = [case['precipitation'], ds.divergence, ds.vorticity, case.get('precipitation_accumulation')]
        levels = [PRECIP_LEVELS, DIV_LEVELS, VORT_LEVELS, ACCUM_LEVELS]
        cmaps = ['YlGnBu', 'RdBu_r', 'PuOr_r', 'YlGnBu']
        start, end = pd.Timestamp(meta['window_start_utc']), pd.Timestamp(meta['window_end_exclusive_utc'])
        interval = f'{start:%m-%d %H:%M}–{end:%m-%d %H:%M} UTC'
        snapshot = pd.Timestamp(meta['view_hour_utc'])
        acc_start, acc_end = pd.Timestamp(meta['accumulation_start_utc']), pd.Timestamp(meta['accumulation_end_exclusive_utc'])
        acc_interval = f'{acc_start:%m-%d %H:%M}–{acc_end:%m-%d %H:%M} UTC'
        acc_name = (f"IMERG running accumulation ({meta['accumulation_hours']:g} h)"
                    if meta['accumulation_mode'] == 'event_start' else f"IMERG accumulation ({meta['hours']} h)")
        acc_title = (acc_name+'\n'+('From event start: ' if meta['accumulation_mode']=='event_start' else 'Window: ')+acc_interval
            if meta['accumulation_status'] != 'not_started' else
            f'IMERG running accumulation — not begun\nEvent starts {acc_start:%m-%d %H:%M} UTC')
        divergence_name = ('925-hPa divergence — hourly snapshot\n'+f'{snapshot:%m-%d %H:%M} UTC'
            if meta['hours'] == 1 else
            f"925-hPa divergence — mean ({meta['hours']} hourly fields)\n"
            f"Samples: {start:%m-%d %H:%M}–{snapshot:%m-%d %H:%M} UTC")
        names = [f"IMERG mean rate ({meta['hours']} h)\nWindow: {interval}",
                 divergence_name, f'925-hPa vorticity + wind / MSLP\nSnapshot: {snapshot:%m-%d %H:%M} UTC',
                 acc_title]
        for col, ax in enumerate(axes[r,:4]):
            decorate(ax)
            field = fields[col]
            ax.set_title(header+'\n'+names[col], fontsize=10)
            if field is None or not bool(field.notnull().any()):
                message = ('Selected hour is before event start\nRunning accumulation has not begun'
                           if col == 3 and meta['accumulation_status'] == 'not_started' else
                           'Accumulation unavailable\nComplete half-hourly coverage required'
                           if col == 3 else 'IMERG unavailable / insufficient coverage\nSee metadata for the reason')
                ax.text(.5, .5, message,
                    ha='center', va='center', transform=ax.transAxes,
                    bbox={'facecolor':'white', 'alpha':.9}, fontsize=10)
                continue
            image = ax.pcolormesh(field.longitude, field.latitude, field.values,
                cmap=cmaps[col], norm=colors.BoundaryNorm(levels[col], 256),
                transform=ccrs.PlateCarree(), shading='auto', rasterized=True)
            bar = fig.colorbar(image, ax=ax, orientation='horizontal', shrink=.9, pad=.04,
                         extend='max' if col in (0,3) else 'both',
                         label=('mm h⁻¹' if col==0 else 'mm' if col==3 else
                                'D (10⁻⁵ s⁻¹)\nNegative/blue: convergence; positive/red: divergence'
                                if col==1 else '10⁻⁵ s⁻¹'))
            bar.ax.tick_params(labelsize=8)
            if (col == 0 and meta.get('imerg_status') != 'complete'
                    or col == 3 and meta.get('accumulation_status') != 'complete'):
                ax.text(.02, .02, 'PARTIAL IMERG COVERAGE', transform=ax.transAxes,
                        bbox={'facecolor':'white', 'alpha':.9}, fontsize=9)
        ax = axes[r, 2]
        slp_levels = np.arange(960, 1052, 4)
        contours = ax.contour(ds.longitude, ds.latitude, ds.mslp, levels=slp_levels,
                             colors='.25', linewidths=.65, transform=ccrs.PlateCarree())
        ax.clabel(contours, fontsize=7, fmt='%d')
        step = 5
        q = ax.quiver(ds.longitude.values[::step], ds.latitude.values[::step],
            ds.u.values[::step,::step], ds.v.values[::step,::step],
            transform=ccrs.PlateCarree(), scale=350, width=.002)
        ax.quiverkey(q, .82, -.08, 10, '10 m s⁻¹', labelpos='E')
        annotate_mslp_lows(ax, ds, meta)
        axes[r,0].legend(loc='lower left', fontsize=7)
        satellite_date = meta.get('satellite_mosaic_date_utc', 'unknown date')
        platform = meta.get('satellite_platform', 'Visible satellite')
        axes[r,3].legend(loc='lower left', fontsize=7)
        for col, field_name in [(4,'satellite_image'), (5,'cloud_rgb_image')]:
            ax = axes[r,col]
            image = case.get(field_name)
            if image is not None:
                # WMS EPSG:4326 PNG rows run north (top) to south (bottom).
                west, east, south, north = DOMAIN
                ax.imshow(image, origin='upper', extent=(west,east,south,north),
                          transform=ccrs.PlateCarree(), zorder=1)
            decorate(ax)
            product = 'visible true color' if col==4 else '7–2–1 cloud/snow RGB'
            ax.set_title(f"{meta['label']}\n" + f'{platform} {product}\n{satellite_date} UTC date · daytime mosaic', fontsize=10)
            caption = ('Daily daytime mosaic; not matched to the weather hour' if col==4 else
                       'Water clouds: white; ice clouds/snow: cyan–blue\nOpaque upper clouds still obscure lower clouds')
            if meta.get('satellite_selection_note'):
                caption += '\n' + meta['satellite_selection_note']
            ax.text(.5, -.10, caption, ha='center', va='top', transform=ax.transAxes, fontsize=9)
            if image is None:
                error_key = 'satellite_error' if col == 4 else 'cloud_rgb_satellite_error'
                reason = meta.get(error_key, 'No usable image returned')
                ax.text(.5,.5,'Satellite imagery unavailable\n' + '\n'.join(textwrap.wrap(reason, 50))
                        + '\nTry another platform or adjacent day',
                        ha='center', va='center', transform=ax.transAxes,
                        bbox={'facecolor':'white','alpha':.9},fontsize=10)
            ax.legend(loc='lower left', fontsize=7)
    if stem:
        save_figure(fig, cases, stem)
    if show:
        plt.show()
    return fig

def save_figure(fig, cases, stem):
    # Include settings to avoid silently reusing a figure from a different window/domain.
    safe = re.sub(r'[^A-Za-z0-9_.-]+', '_', stem)
    for extension in ('png', 'pdf'):
        fig.savefig(OUTPUT_DIR / f'{safe}.{extension}', dpi=240, bbox_inches='tight')
    atomic_csv(pd.DataFrame([case['metadata'] for case in cases]), OUTPUT_DIR / f'{safe}_metadata.csv')
    print('Exported PNG, PDF, and metadata:', OUTPUT_DIR / safe)

def figure_stem(row, hours, offset=0, accumulation_mode='event_start'):
    hour = pd.Timestamp(row.event_peak) + pd.Timedelta(hours=offset)
    return (f'event_{hour:%Y%m%dT%H%M}_{hours}h_{cache_id(hour,hours)}_running_v10_vortex_labels_v3_'
            f'{accumulation_mode}_start{pd.Timestamp(row.event_start):%Y%m%dT%H%M}')

def run_batch(frame, hours=1, limit=None, offsets=(-12, 0, 12), satellite_platform='Auto',
              satellite_day_offset=0, accumulation_mode='event_start', retry_incomplete=False):
    return run_case_review_batch(
        frame, OUTPUT_DIR, load_case=get_case, release_memory=release_review_memory,
        check_auth=lambda: require_earthdata_auth(globals().get('auth')),
        export_phase=make_review_phase_exporter(globals()),
        render_cases=lambda cases: plot_cases(cases, show=False), label_for=vortex_plot_label,
        refresh_event=lambda row: attach_vortex_flags(pd.DataFrame([row])).iloc[0],
        hours=hours, limit=limit, offsets=offsets, satellite_platform=satellite_platform,
        retry_incomplete=retry_incomplete,
        satellite_day_offset=satellite_day_offset, accumulation_mode=accumulation_mode,
        settings=dict(domain=DOMAIN, polygons=POLYGONS, era5_store=ERA5_STORE,
                      imerg_product=IMERG_PRODUCT, imerg_version=IMERG_VERSION,
                      imerg_min_coverage=MIN_PIXEL_TEMPORAL_COVERAGE,
                      label_scheme=VORTEX_LABEL_SCHEME, vortex_signature=vortex_signature()))


"""Small, resumable vortex-association screen for Notebook 35 (not causal attribution)."""
VORTEX_SCREEN_SETTINGS = {
    'version': 1, 'domain': DOMAIN if 'DOMAIN' in globals() else None,
    'level_hpa': 925, 'window_hours_each_side': 12,
    'minimum_consecutive_hours': 3, 'maximum_hourly_jump_km': 150,
    'pressure_closure_hpa': .5, 'wind_annulus_km': [100,250],
    'minimum_ring_wind_ms': 2, 'minimum_sector_fraction': .5,
    'minimum_sector_wind_ms': .5, 'minimum_mean_vorticity_1e5': 1,
    'minimum_positive_vorticity_fraction': .6, 'vorticity_disk_km':150,
    'minimum_valid_coverage': .8, 'minimum_valid_sector_coverage': .6,
    'allow_land_centers': True, 'exclude_below_ground_925hpa_samples': True,
}

def vortex_signature():
    settings = dict(VORTEX_SCREEN_SETTINGS, domain=list(DOMAIN), era5_store=ERA5_STORE)
    return hashlib.sha256(json.dumps(settings, sort_keys=True).encode()).hexdigest()[:16]

def vortex_cache_dir():
    path = OUTPUT_DIR/'vortex_screen'/vortex_signature()
    path.mkdir(parents=True, exist_ok=True)
    return path

def atomic_json(value, path):
    temp = path.with_suffix('.tmp.json')
    temp.write_text(json.dumps(value, indent=1, allow_nan=False))
    temp.replace(path)

def event_vortex_path(row):
    key = hashlib.sha256(str(row.review_key).encode()).hexdigest()[:20]
    return vortex_cache_dir()/f'event_{key}.json'

def cached_event_vortex(row):
    path = event_vortex_path(row)
    if path.exists():
        try:
            result = json.loads(path.read_text())
            if result['status'] == 'complete' and result['review_key'] == row.review_key:
                return result
        except (ValueError,KeyError):
            pass
    return None

def attach_vortex_flags(frame):
    frame = frame.copy()
    vortex_cache_dir()  # ensure the parent exists before writing the active screen pointer
    atomic_json(dict(signature=vortex_signature(), label_scheme=VORTEX_LABEL_SCHEME),
                OUTPUT_DIR/'vortex_screen'/'active_screen.json')
    records = [cached_event_vortex(row) for _,row in frame.iterrows()]
    frame['vortex_scan_status'] = ['complete' if r else 'not_scanned' for r in records]
    frame['vortex_detected'] = [bool(r and r['vortex_detected']) for r in records]
    frame['vortex_first_detection_utc'] = [r.get('first_detection_utc','') if r else '' for r in records]
    frame['vortex_detection_hours'] = [r.get('detection_hours',0) if r else 0 for r in records]
    frame['vortex_screen_signature'] = [r.get('signature', vortex_signature()) if r else '' for r in records]
    return frame

def vortex_distance_km(a,b):
    phi1,phi2 = np.deg2rad([a['latitude'],b['latitude']])
    dlambda = np.deg2rad(a['longitude']-b['longitude'])
    value = np.sin((phi1-phi2)/2)**2+np.cos(phi1)*np.cos(phi2)*np.sin(dlambda/2)**2
    return float(2*6371*np.arcsin(np.sqrt(np.clip(value,0,1))))

def persistent_vortex_tracks(hourly):
    """Link only consecutive-hour centers; no interpolation across missing hours."""
    tracks, previous = [], []
    for record in sorted(hourly, key=lambda r:r['hour_utc']):
        now = pd.Timestamp(record['hour_utc'])
        current = [dict(c,hour_utc=record['hour_utc']) for c in record['centers']]
        links = sorted((vortex_distance_km(c,tracks[t][-1]),i,t)
            for i,c in enumerate(current) for t in previous
            if now-pd.Timestamp(tracks[t][-1]['hour_utc']) == pd.Timedelta(hours=1))
        used_i, used_t, next_ids = set(),set(),[]
        for distance,i,t in links:
            if distance <= 150 and i not in used_i and t not in used_t:
                tracks[t].append(current[i]); used_i.add(i); used_t.add(t); next_ids.append(t)
        for i,center in enumerate(current):
            if i not in used_i:
                next_ids.append(len(tracks)); tracks.append([center])
        previous = next_ids
    return [track for track in tracks if len(track)>=3]

def load_vortex_hourly(start, end):
    """Read one hour at a time and persist each completed vortex snapshot to Drive."""
    expected = pd.date_range(start, end, freq='h')
    root = vortex_cache_dir()
    paths = {hour: root / f'hour_{hour:%Y%m%dT%H%M}.json' for hour in expected}
    missing = [hour for hour, path in paths.items() if not path.exists()]
    if missing:
        global era5
        if 'era5' not in globals():
            era5 = xr.open_zarr(ERA5_STORE, chunks=None, storage_options={'token': 'anon'})
        for index, hour in enumerate(missing, start=1):
            print(f'Vortex winds: {index}/{len(missing)} missing hours | {hour} UTC', flush=True)
            field = read_review_era5_hour(era5, hour,
                ('u_component_of_wind', 'v_component_of_wind', 'mean_sea_level_pressure', 'surface_pressure'), DOMAIN)
            dx, dy = mpcalc.lat_lon_grid_deltas(field.longitude.values, field.latitude.values)
            u, v = field.u_component_of_wind.values, field.v_component_of_wind.values
            zeta = mpcalc.vorticity(u*units('m/s'), v*units('m/s'), dx=dx, dy=dy).magnitude*1e5
            pressure = field.mean_sea_level_pressure.values/100
            surface = field.surface_pressure.values
            valid = np.isfinite(surface) & (surface > 92500)
            centers, rejected = [], []
            for center in detect_mslp_lows(pressure, field.longitude.values, field.latitude.values, max_centers=100):
                evidence = cyclone_circulation_evidence(center, field.longitude.values, field.latitude.values,
                                                       u, v, zeta, valid_mask=valid)
                if evidence['passes_circulation_screen']:
                    centers.append(dict(center, **evidence))
                else:
                    rejected.append(dict(center, **evidence))
            atomic_json(dict(hour_utc=hour.isoformat(), centers=centers, rejected=rejected), paths[hour])
            del field, u, v, zeta, pressure, surface, valid, centers, rejected
            release_review_memory()
    return [json.loads(paths[hour].read_text()) for hour in expected]

def scan_event_vortices(row):
    cached = cached_event_vortex(row)
    if cached is not None:
        return cached
    peak = pd.Timestamp(row.event_peak)
    start,end = peak-pd.Timedelta(hours=12),peak+pd.Timedelta(hours=12)
    print(f'Vortex check: {start} to {end} UTC (25 hourly snapshots)',flush=True)
    hourly = load_vortex_hourly(start,end)
    tracks = persistent_vortex_tracks(hourly)
    times = sorted({p['hour_utc'] for track in tracks for p in track})
    result = dict(status='complete',review_key=row.review_key,peak_utc=peak.isoformat(),
        start_utc=start.isoformat(),end_utc=end.isoformat(),checked_hours=len(hourly),
        vortex_detected=bool(tracks),first_detection_utc=times[0] if times else '',
        detection_hours=len(times),tracks=tracks,signature=vortex_signature(),
        interpretation='Automated resolved-vortex screen, not JPCZ formation attribution')
    atomic_json(result,event_vortex_path(row))
    return result

def vortex_case_metadata(row,hour):
    result = scan_event_vortices(row)
    hour = pd.Timestamp(hour)
    if pd.Timestamp(result['start_utc']) <= hour <= pd.Timestamp(result['end_utc']):
        tracks = result['tracks']
        scope = 'event_peak_plus_minus_12h'
    else:
        tracks = persistent_vortex_tracks(load_vortex_hourly(hour-pd.Timedelta(hours=1),hour+pd.Timedelta(hours=1)))
        scope = 'selected_hour_plus_minus_1h; event flag still uses peak +/-12h'
    centers = [p for track in tracks for p in track if pd.Timestamp(p['hour_utc'])==hour]
    return dict(vortex_detected=result['vortex_detected'],vortex_scan_status=result['status'],
        vortex_screen_signature=result.get('signature',''),
        vortex_window_start_utc=result['start_utc'],vortex_window_end_utc=result['end_utc'],
        vortex_checked_hours=result['checked_hours'],vortex_map_centers=json.dumps(centers),
        vortex_map_status='screen_detected' if centers else 'none_passed_screen',
        vortex_map_scope=scope,vortex_screen_settings=json.dumps(dict(VORTEX_SCREEN_SETTINGS,domain=list(DOMAIN))))

def scan_vortex_catalog(frame,limit=None):
    """Resumable; detector catalogs and manual labels are never overwritten."""
    processed,errors = 0,[]
    for index,(_,row) in enumerate(frame.iterrows(),1):
        if cached_event_vortex(row) is not None:
            continue
        if limit is not None and processed>=limit:
            break
        processed += 1
        print(f'Checking event {int(row.event_number)} ({index}/{len(frame)})',flush=True)
        try:
            result = scan_event_vortices(row)
            print('  '+('vortex detected' if result['vortex_detected'] else 'no vortex passed screen'),flush=True)
        except Exception as error:
            errors.append(dict(review_key=row.review_key,error=f'{type(error).__name__}: {error}'))
            print('  NOT COMPLETED:',errors[-1]['error'],flush=True)
    updated = attach_vortex_flags(frame)
    atomic_csv(updated[['review_key',*DATE_COLUMNS,'event_number','vortex_scan_status','vortex_detected',
                       'vortex_first_detection_utc','vortex_detection_hours']],
               vortex_cache_dir()/'event_screen_summary.csv')
    if errors:
        atomic_csv(pd.DataFrame(errors),vortex_cache_dir()/'scan_errors.csv')
    print(f"Vortex coverage: {updated.vortex_scan_status.eq('complete').sum()}/{len(updated)} checked; "
          f"{updated.vortex_detected.sum()} flagged; {len(errors)} errors in this run.",flush=True)
    return updated


# --- Resumable three-time batch exports ---
"""Resumable three-time Notebook 35 exports using its existing case reader and plots."""
import gc
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

BATCH_EXPORT_VERSION = 1
BATCH_DATE_COLUMNS = ('event_start', 'event_end', 'event_peak')


class EarthdataLoginRequired(RuntimeError):
    """A session problem must stop the batch, rather than produce missing-data pages."""
    requires_earthdata_login = True


def require_earthdata_auth(auth):
    """Check the Auth returned by the notebook's explicit, non-persistent login cell."""
    if not getattr(auth, 'authenticated', False):
        raise EarthdataLoginRequired(
            'NASA Earthdata login is missing in this runtime. Run the cell under '
            '"NASA authentication for new IMERG map requests" and wait for '
            '"NASA Earthdata authenticated", then rerun the batch with the same settings. '
            'Saved exports and cached data will be reused; unfinished phases will resume. '
            'Use BATCH_RETRY_INCOMPLETE = True only to retry saved data gaps.')


def batch_json_value(value):
    if isinstance(value, dict):
        return {str(k): batch_json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [batch_json_value(v) for v in value]
    if isinstance(value, np.generic):
        return batch_json_value(value.item())
    if isinstance(value, (pd.Timestamp, Path)):
        return str(value)
    if value is None or value is pd.NA or (isinstance(value, float) and not np.isfinite(value)):
        return None
    return value


def batch_atomic_json(value, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name('.' + path.name + '.tmp')
    temporary.write_text(json.dumps(batch_json_value(value), indent=2, allow_nan=False))
    temporary.replace(path)


def batch_atomic_csv(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name('.' + path.name + '.tmp')
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def batch_digest(value):
    encoded = json.dumps(batch_json_value(value), sort_keys=True, allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()[:16]


def batch_screen_signature(row, settings):
    """Reloaded catalog rows may omit a signature already fixed by reader settings."""
    value = row.get('vortex_screen_signature', '')
    if isinstance(value, str) and value:
        return value
    value = (settings or {}).get('vortex_signature', '')
    return value if isinstance(value, str) else ''


def batch_request_matches(saved, current):
    # Older rows sometimes omitted this duplicate of config.reader_settings.vortex_signature.
    # Preserve every other comparison, including the complete reader/settings identity.
    def canonical(request):
        result = dict(request)
        settings = result.get('config', {}).get('reader_settings', {})
        result['vortex_screen_signature'] = batch_screen_signature(result, settings)
        return result
    return canonical(saved) == canonical(current)


def batch_data_status(metadata):
    """Unavailable satellite archives are explicit, permanent gaps; transient gaps retry."""
    rain = metadata.get('imerg_status') == 'complete'
    dynamics = metadata.get('era5_map_status', 'complete') == 'complete'
    total = metadata.get('accumulation_status') in ('complete', 'not_started')
    satellite = (metadata.get('satellite_status') == 'available_daily_mosaic'
                 and metadata.get('cloud_rgb_satellite_status') == 'available_daily_mosaic')
    archive_gap = all('predates archive availability' in str(metadata.get(name, '')).lower()
                      for name in ('satellite_error', 'cloud_rgb_satellite_error'))
    if dynamics and rain and total and (satellite or archive_gap):
        return 'complete_archive_gap' if archive_gap else 'complete'
    return 'partial_data'


def batch_combine_event_pdf(paths, destination):
    """Merge only one event's pages at a time, keeping memory bounded."""
    from pypdf import PdfWriter
    temporary = destination.with_name('.' + destination.stem + '.tmp.pdf')
    writer = PdfWriter()
    try:
        for path in paths:
            writer.append(str(path))
        with temporary.open('wb') as stream:
            writer.write(stream)
        temporary.replace(destination)
    finally:
        writer.close()
        temporary.unlink(missing_ok=True)


def batch_export_phase(row, files, *, metadata, load_case, render_cases, hours, offset,
                       satellite_platform, satellite_day_offset, accumulation_mode, dpi, progress=print):
    """Use the same reader/renderer for an in-process or isolated phase export."""
    import matplotlib.pyplot as plt
    figure = None
    figures_before = set(plt.get_fignums())
    try:
        try:
            case = load_case(row, hours=hours, offset=offset,
                satellite_platform=satellite_platform, satellite_day_offset=satellite_day_offset,
                accumulation_mode=accumulation_mode)
            metadata.update(case['metadata'])
            dynamics = case.get('dynamics')
            if dynamics is not None:
                names = ('divergence', 'vorticity', 'u', 'v', 'mslp')
                missing = [name for name in names if name not in dynamics
                           or not np.isfinite(dynamics[name].values).any()]
                if missing:
                    raise ValueError('ERA5 maps unavailable for: ' + ', '.join(missing))
                metadata['era5_map_status'] = ('complete' if all(
                    np.isfinite(dynamics[name].values).all() for name in names) else 'partial')
            figure = render_cases([case])
            status = batch_data_status(metadata)
        except Exception as error:
            if isinstance(error, MemoryError) or getattr(error, 'requires_earthdata_login', False):
                raise
            for figure_id in set(plt.get_fignums()) - figures_before:
                plt.close(figure_id)
            status = 'failed'
            metadata['error'] = f'{type(error).__name__}: {error}'
            progress('  ' + metadata['error'])
            figure = plt.figure(figsize=(18, 10.5), layout='constrained')
            axis = figure.add_subplot()
            axis.axis('off')
            axis.text(.5, .65, f'Event {int(row.event_number)} · {offset:+d} h from peak\n'
                      f"{metadata['view_hour_utc']} UTC", ha='center', va='center', fontsize=18,
                      transform=axis.transAxes)
            axis.text(.5, .4, 'Case data unavailable; this phase will be retried.\n' + metadata['error'],
                      ha='center', va='center', wrap=True, fontsize=12, transform=axis.transAxes)
        for extension in ('png', 'pdf'):
            destination = Path(files[extension])
            temporary = destination.with_name('.' + destination.stem + '.tmp.' + extension)
            figure.savefig(temporary, format=extension, dpi=dpi, bbox_inches='tight')
            temporary.replace(destination)
        return metadata, status
    finally:
        for figure_id in set(plt.get_fignums()) - figures_before:
            plt.close(figure_id)


def run_case_review_batch(frame, output_dir, *, load_case, render_cases, label_for,
                          refresh_event=None, release_memory=None, check_auth=None, export_phase=None,
                          hours=1, limit=None, offsets=(-12, 0, 12),
                          satellite_platform='Auto', satellite_day_offset=0,
                          accumulation_mode='event_start', settings=None, dpi=180,
                          retry_incomplete=False, progress=print):
    """Resume missing/changed exports; retry saved partial products only when requested.

    Per event: three PNG/PDF/metadata sets plus a three-page PDF and combined CSV.
    The root manifest/CSV always describes the supplied current inventory, not old folders.
    Source data caches and the event catalog are owned by the existing notebook readers.
    """
    import matplotlib.pyplot as plt
    try:
        import pypdf
    except ModuleNotFoundError as error:
        raise RuntimeError('Run Notebook 35 installation cell first to install pypdf, then retry batch.') from error
    if hours not in (1, 12) or tuple(offsets) != (-12, 0, 12):
        raise ValueError('Choose 1 or 12 hours; the batch phases are always -12, 0, +12 hours.')
    if limit is not None and (not isinstance(limit, int) or limit < 1):
        raise ValueError('Use EVENTS_PER_RUN = None for all remaining events, or a positive integer.')
    if satellite_platform not in ('Auto', 'Terra', 'Aqua') or satellite_day_offset not in (-1, 0, 1):
        raise ValueError('Choose Auto/Terra/Aqua and a satellite day offset of -1, 0, or +1.')
    if accumulation_mode not in ('event_start', 'window'):
        raise ValueError('Choose event_start or window accumulation.')
    if not set((*BATCH_DATE_COLUMNS, 'review_key', 'event_number')).issubset(frame):
        raise ValueError('Load the current Notebook 35 catalog before running batch.')
    if frame.review_key.duplicated().any():
        raise ValueError('Duplicate event identities in batch inventory.')
    # Before source reads or checkpoint changes, fail clearly if the login cell was skipped.
    if check_auth:
        check_auth()
    config = dict(export_version=BATCH_EXPORT_VERSION, hours=hours, offsets=list(offsets),
                  satellite_platform=satellite_platform, satellite_day_offset=satellite_day_offset,
                  accumulation_mode=accumulation_mode, dpi=dpi, reader_settings=settings or {})
    root = Path(output_dir) / 'batch_evolution' / f'{hours}h_{satellite_platform}_{batch_digest(config)}'
    root.mkdir(parents=True, exist_ok=True)
    batch_atomic_json(config, root / 'batch_settings.json')
    batch_atomic_json(dict(run_status='running', selected_events=len(frame),
                           requested_phases=len(frame)*3), root / 'batch_summary.json')
    progress(f'Batch folder: {root}')
    progress(f'{len(frame)} events; three times per event; satellite mode {satellite_platform}.')
    jobs, attempted_events, reused_phases = [], 0, 0

    for _, original in frame.iterrows():
        row = refresh_event(original.copy()) if refresh_event else original.copy()
        event_dir = root / f'event_{int(row.event_number):04d}_{batch_digest(str(row.review_key))}'
        event_dir.mkdir(exist_ok=True)
        event_jobs, touched_event = [], False
        for offset in offsets:
            if refresh_event:
                row = refresh_event(row)
            phase = 'peak' if offset == 0 else ('minus12h' if offset < 0 else 'plus12h')
            stem = event_dir / phase
            state_path = stem.with_suffix('.json')
            files = {'png': stem.with_suffix('.png'), 'pdf': stem.with_suffix('.pdf'),
                     'metadata_csv': event_dir / f'{phase}_metadata.csv'}
            def request_identity():
                return batch_json_value(dict(config=config, review_key=str(row.review_key),
                    event_number=int(row.event_number), offset_hours=offset,
                    event_start=row.event_start, event_end=row.event_end, event_peak=row.event_peak,
                    label=label_for(row), vortex_scan_status=row.get('vortex_scan_status', ''),
                    vortex_screen_signature=batch_screen_signature(row, settings)))
            identity = request_identity()
            saved = None
            if state_path.exists() and all(path.is_file() and path.stat().st_size for path in files.values()):
                try:
                    candidate = json.loads(state_path.read_text())
                    if batch_request_matches(candidate['request'], identity):
                        saved = candidate
                except (KeyError, ValueError, OSError):
                    pass
            wrote_phase = False
            if saved and (saved['record']['status'] in ('complete', 'complete_archive_gap')
                          or (not retry_incomplete and saved['record']['status'] in ('partial_data', 'failed'))):
                record = saved['record']
                reused_phases += 1
                if reused_phases % 75 == 0:
                    progress(f'Reused {reused_phases} saved phases; no maps redrawn. '
                             f'Checking event {int(row.event_number)} of {len(frame)}.')
            elif limit is not None and not touched_event and attempted_events >= limit:
                # Inventory still includes saved partial products and work left for later runs.
                record = saved['record'] if saved else dict(review_key=str(row.review_key),
                    event_number=int(row.event_number), offset_hours=offset, status='not_attempted',
                    **{name: str(path) for name, path in files.items()})
            else:
                if not touched_event:
                    touched_event = True
                    attempted_events += 1
                hour = pd.Timestamp(row.event_peak) + pd.Timedelta(hours=offset)
                progress(f'Event {int(row.event_number)} | {offset:+d} h | {hour} UTC | {satellite_platform}')
                metadata = {name: row[name] for name in BATCH_DATE_COLUMNS}
                metadata.update(review_key=str(row.review_key), event_number=int(row.event_number),
                                offset_hours=offset, view_hour_utc=hour,
                                hours=hours, accumulation_mode=accumulation_mode,
                                satellite_day_offset=satellite_day_offset,
                                catalog_provisional=row.get('catalog_provisional', False),
                                satellite_requested_platform=satellite_platform)
                try:
                    if check_auth:
                        check_auth()
                    options = dict(metadata=metadata, hours=hours, offset=offset,
                        satellite_platform=satellite_platform, satellite_day_offset=satellite_day_offset,
                        accumulation_mode=accumulation_mode, dpi=dpi)
                    if export_phase:
                        metadata, status = export_phase(row, files, **options)
                    else:
                        metadata, status = batch_export_phase(row, files, load_case=load_case,
                            render_cases=render_cases, progress=progress, **options)
                except Exception as error:
                    authentication = getattr(error, 'requires_earthdata_login', False)
                    batch_atomic_json(dict(run_status='paused_authentication' if authentication else 'paused_worker',
                        selected_events=len(frame), attempted_events=attempted_events,
                        requested_phases=len(frame)*3, saved_phases=len(jobs),
                        interrupted_event=int(row.event_number), interrupted_offset_hours=offset,
                        error=str(error)), root / 'batch_summary.json')
                    (release_memory or gc.collect)()
                    raise
                # A first case read can finish the event's previously unchecked vortex screen.
                for name in ('vortex_detected', 'vortex_scan_status', 'vortex_screen_signature'):
                    if name in metadata:
                        row[name] = metadata[name]
                identity = request_identity()
                metadata['batch_status'] = status
                batch_atomic_csv(pd.DataFrame([metadata]), files['metadata_csv'])
                record = batch_json_value(dict(**metadata, status=status,
                    **{name: str(path) for name, path in files.items()}))
                batch_atomic_json(dict(request=identity, record=record), state_path)
                wrote_phase = True
                (release_memory or gc.collect)()
            event_jobs.append(record)
            jobs.append(record)
            # Update after each phase, including a partial/failed phase, so a disconnect loses little.
            if wrote_phase:
                batch_atomic_csv(pd.DataFrame(jobs), root / 'batch_manifest.csv')
                batch_atomic_csv(pd.DataFrame(jobs), root / 'all_cases_metadata.csv')
        # Each phase has its own outputs. This PDF groups all three times for one event.
        if all(Path(job.get('pdf', '')).is_file() and job['status'] != 'not_attempted' for job in event_jobs):
            event_pdf = event_dir / 'all_three_times.pdf'
            sources = [Path(job['pdf']) for job in event_jobs]
            if (not event_pdf.exists() or event_pdf.stat().st_mtime_ns < max(path.stat().st_mtime_ns for path in sources)):
                batch_combine_event_pdf(sources, event_pdf)
            for job in event_jobs:
                job['event_pdf'] = str(event_pdf)
                job['event_metadata_csv'] = str(event_dir / 'all_three_times_metadata.csv')
            batch_atomic_csv(pd.DataFrame(event_jobs), event_dir / 'all_three_times_metadata.csv')
            (release_memory or gc.collect)()
    result = pd.DataFrame(jobs)
    batch_atomic_csv(result, root / 'batch_manifest.csv')
    batch_atomic_csv(result, root / 'all_cases_metadata.csv')
    counts = result.status.value_counts().to_dict() if not result.empty else {}
    batch_atomic_json(dict(run_status='finished', selected_events=len(frame), attempted_events=attempted_events,
                           requested_phases=len(frame)*3, reused_phases=reused_phases,
                           retry_incomplete=retry_incomplete, statuses=counts), root / 'batch_summary.json')
    progress(f'Attempted {attempted_events} events this run. Phase status: {counts}.')
    progress(f'All PDF/PNG/CSV exports are together in {root}')
    result.attrs['output_dir'] = str(root)
    return result


# --- Bounded ERA5 source reads ---
"""Bound source-chunk decoding and detach compact ERA5 fields for Notebook 35."""
import gc
import sys

import numpy as np
import pandas as pd
import xarray as xr
import zarr


def release_review_memory():
    """Collect closed figures and return free allocator pages on Linux/Colab."""
    gc.collect()
    if sys.platform.startswith('linux'):
        try:
            import ctypes
            library = ctypes.CDLL(None)
            trim = getattr(library, 'malloc_trim', None)
            if trim is not None:
                trim(0)
        except (AttributeError, OSError):
            pass


def read_review_era5_hour(dataset, hour, variables, domain, level=925):
    """Read exactly one source time and one variable at a time, then copy the region.

    ARCO wind chunks contain every pressure level and the globe. A regional slice
    must not retain a view into that decoded buffer after the read is finished.
    """
    hour = pd.Timestamp(hour)
    west, east, south, north = domain
    latitude = slice(north, south) if dataset.latitude[0] > dataset.latitude[-1] else slice(south, north)
    longitude = slice(west, east) if dataset.longitude[0] < dataset.longitude[-1] else slice(east, west)
    selected = dataset[list(variables)].sel(time=hour, longitude=longitude, latitude=latitude)
    if 'level' in selected.dims or 'level' in selected.coords:
        selected = selected.sel(level=level)
    coordinates = {name: np.array(selected[name].values, copy=True) for name in ('latitude', 'longitude')}
    fields = {}
    with zarr.config.set({'async.concurrency': 1, 'threading.max_workers': 1}):
        from numcodecs import blosc
        blosc.set_nthreads(1)
        for name in variables:
            loaded = selected[name].transpose('latitude', 'longitude').load(scheduler='synchronous')
            compact = xr.DataArray(np.array(loaded.values, copy=True, order='C'),
                dims=('latitude', 'longitude'), coords=coordinates, attrs=dict(loaded.attrs), name=name)
            fields[name] = compact
            # Replace the loaded view before releasing it, in case its Variable is shared.
            selected[name] = compact
            del loaded, compact
            release_review_memory()
    del selected
    return xr.Dataset(fields, coords=coordinates)


def read_review_era5_window(dataset, times, variables, domain, level=925):
    """Retain only compact regional snapshots when a 12-hour mean is requested."""
    records = []
    for hour in pd.DatetimeIndex(times):
        record = read_review_era5_hour(dataset, hour, variables, domain, level=level)
        records.append(record.expand_dims(time=[hour]))
    result = xr.concat(records, dim='time')
    del records
    release_review_memory()
    return result
