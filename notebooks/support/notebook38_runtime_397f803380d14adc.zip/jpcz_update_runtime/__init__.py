"""Versioned Notebook 38 detector helpers."""
