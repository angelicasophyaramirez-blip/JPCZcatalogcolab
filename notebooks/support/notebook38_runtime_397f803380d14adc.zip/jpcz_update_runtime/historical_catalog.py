"""Safe, resumable helpers for a full-record historical JPCZ catalog.

This module deliberately does not modify the existing 2000--2025 catalog.
It creates a second catalog whose anomaly baseline is formed from complete
NDJF seasons, while allowing matching 2000--2025 monthly D12 checkpoints to
be reused as read-only inputs.
"""

from __future__ import annotations

import calendar
import gc
from collections.abc import Iterable, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr
import metpy.calc as mpcalc
from metpy.units import units

from .detect import (
    DetectionGeometry,
    compute_rolling_mean,
    count_events_from_threshold,
    threshold_from_std,
)


@dataclass(frozen=True)
class NDJFMonth:
    """One calendar month belonging to a complete NDJF season."""

    season_year: int
    year: int
    month: int


class IncompleteDivergenceError(ValueError):
    """A missing input interrupts the continuous series; retain its finite prefix."""

    def __init__(self, hourly: xr.DataArray, details: dict):
        self.hourly, self.details = hourly, details
        super().__init__(
            f"{details['first_invalid_time_utc']}: {details['cause']}; "
            f"{details['nonfinite_polygon_divergence_cells']} nonfinite polygon divergence cells. "
            f"Preserved {hourly.sizes['time']} preceding hourly means; no missing hour was skipped.")


def complete_ndjf_months(
    first_season_year: int = 1940,
    last_season_year: int = 2025,
) -> tuple[NDJFMonth, ...]:
    """Return Nov--Feb records for complete NDJF seasons.

    ``season_year=1940`` means November--December 1940 followed by
    January--February 1941.  This intentionally avoids the partial
    January--February 1940 season, for which November--December 1939 are not
    available in ERA5.
    """
    if last_season_year < first_season_year:
        raise ValueError("last_season_year must be >= first_season_year")

    records: list[NDJFMonth] = []
    for season_year in range(first_season_year, last_season_year + 1):
        records.extend(
            [
                NDJFMonth(season_year, season_year, 11),
                NDJFMonth(season_year, season_year, 12),
                NDJFMonth(season_year, season_year + 1, 1),
                NDJFMonth(season_year, season_year + 1, 2),
            ]
        )
    return tuple(records)


def checkpoint_path_for_month(directory: str | Path, record: NDJFMonth) -> Path:
    """Return the standard D12 checkpoint filename for a calendar month."""
    return Path(directory) / f"{record.year}_{record.month:02d}_D.nc"


def find_existing_checkpoint(
    record: NDJFMonth,
    *,
    legacy_monthly_dir: str | Path,
    legacy_december_dir: str | Path | None = None,
) -> Path | None:
    """Find a compatible old checkpoint without writing to its directory."""
    monthly_path = checkpoint_path_for_month(legacy_monthly_dir, record)
    if monthly_path.exists():
        return monthly_path
    if record.month == 12 and legacy_december_dir is not None:
        december_path = Path(legacy_december_dir) / f"december_{record.year}_D.nc"
        if december_path.exists():
            return december_path
    return None


def validate_d12_checkpoint(path: str | Path, record: NDJFMonth) -> tuple[bool, str]:
    """Validate that a checkpoint has the expected month-long trailing-D12 series.

    This checks the timestamp convention and the expected number of valid
    values.  It cannot reconstruct the original polygon geometry from a
    one-dimensional D12 file, so the workflow separately records that legacy
    files are only reused when they came from the established matching ERA5
    detector.
    """
    checkpoint = Path(path)
    if not checkpoint.exists():
        return False, "file missing"
    try:
        D = xr.open_dataarray(checkpoint)
        if "time" not in D.dims:
            return False, "missing time dimension"
        timestamps = pd.DatetimeIndex(D.time.values)
        expected_count = calendar.monthrange(record.year, record.month)[1] * 24 - 11
        expected_start = pd.Timestamp(record.year, record.month, 1, 11)
        expected_end = pd.Timestamp(
            record.year,
            record.month,
            calendar.monthrange(record.year, record.month)[1],
            23,
        )
        if len(timestamps) != expected_count:
            return False, f"expected {expected_count} D12 values, found {len(timestamps)}"
        if timestamps.empty or timestamps[0] != expected_start or timestamps[-1] != expected_end:
            return False, "unexpected D12 time coverage"
        if not timestamps.is_monotonic_increasing or timestamps.has_duplicates:
            return False, "timestamps are not unique and increasing"
        values = np.asarray(D.values)
        if not np.isfinite(values).all():
            return False, "contains non-finite D12 values"
    except Exception as error:  # pragma: no cover - defensive Drive/file handling
        return False, f"unreadable checkpoint: {type(error).__name__}: {error}"
    finally:
        try:
            D.close()
        except (NameError, AttributeError):
            pass
    return True, "valid"


def write_inventory(
    records: Sequence[dict[str, object]], path: str | Path) -> pd.DataFrame:
    """Atomically persist the Drive-resume inventory and return it."""
    inventory_path = Path(path)
    inventory_path.parent.mkdir(parents=True, exist_ok=True)
    inventory = pd.DataFrame(records).sort_values(["season_year", "year", "month"])
    temporary_path = inventory_path.with_suffix(inventory_path.suffix + ".tmp")
    inventory.to_csv(temporary_path, index=False)
    temporary_path.replace(inventory_path)
    return inventory


def write_dataframe_atomic(frame: pd.DataFrame, path: str | Path, *, index: bool = False) -> Path:
    """Write a CSV through a temporary sibling file, then atomically replace it."""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = destination.with_name(f".{destination.stem}.tmp{destination.suffix}")
    frame.to_csv(temporary_path, index=index)
    temporary_path.replace(destination)
    return destination


def write_dataarray_atomic(array: xr.DataArray, path: str | Path) -> Path:
    """Atomically persist a small NetCDF checkpoint to Drive."""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = destination.with_name(f".{destination.stem}.tmp{destination.suffix}")
    array.to_netcdf(temporary_path)
    temporary_path.replace(destination)
    return destination


def initialize_historical_inventory(
    records: Sequence[NDJFMonth],
    *,
    historical_monthly_dir: str | Path,
    legacy_monthly_dir: str | Path,
    legacy_december_dir: str | Path | None = None,
) -> list[dict[str, object]]:
    """Describe whether each month is reusable, already built, or pending.

    A historical-run checkpoint always takes precedence.  Existing catalog
    checkpoints are only *read*; this keeps the established catalog safe.
    """
    historical_dir = Path(historical_monthly_dir)
    rows: list[dict[str, object]] = []
    for record in records:
        new_path = checkpoint_path_for_month(historical_dir, record)
        legacy_path = find_existing_checkpoint(
            record,
            legacy_monthly_dir=legacy_monthly_dir,
            legacy_december_dir=legacy_december_dir,
        )
        new_valid, new_validation = validate_d12_checkpoint(new_path, record)
        legacy_valid = False
        legacy_validation = "not checked"
        if legacy_path is not None:
            legacy_valid, legacy_validation = validate_d12_checkpoint(legacy_path, record)

        if new_valid:
            status, source, selected_path, validation = "complete", "historical_checkpoint", new_path, new_validation
        elif legacy_valid:
            status, source, selected_path, validation = "complete", "reused_legacy_checkpoint", legacy_path, legacy_validation
        else:
            reason = new_validation if new_path.exists() else legacy_validation
            status, source, selected_path, validation = "pending", "new_era5_calculation", new_path, reason
        rows.append(
            {
                **asdict(record),
                "status": status,
                "source": source,
                "checkpoint_path": str(selected_path),
                "checkpoint_validation": validation,
            }
        )
    return rows


def compute_polygon_mean_divergence_series_chunked(
    window_ds: xr.Dataset,
    *,
    geometry: DetectionGeometry,
    chunk_hours: int = 24,
    progress_every_hours: int = 24,
    progress_label: str = "Monthly divergence",
    hourly_checkpoint_path: str | Path | None = None,
) -> tuple[xr.DataArray, xr.DataArray]:
    """Calculate hourly polygon divergence using fast, bounded batches.

    A short wind-data chunk is loaded from ARCO.  MetPy calculates all of the
    chunk's hourly divergence fields in one vectorized call, and those fields
    are immediately reduced to polygon-mean scalars.  Thus a full month-long
    divergence stack is never retained in memory.  The individual hourly
    calculations are the same three-point MetPy finite differences used by
    the established detector; batching changes only execution speed.

    When ``hourly_checkpoint_path`` is supplied, the scalar hourly series is
    atomically saved after every progress interval.  A rerun validates and
    resumes that partial series, so an interrupted month does not start from
    hour zero.  The final trailing 12-hour mean remains computed only from
    the complete hourly series.
    """
    if chunk_hours < 1:
        raise ValueError("chunk_hours must be at least one hour")
    if progress_every_hours < 1:
        raise ValueError("progress_every_hours must be at least one hour")
    if "time" not in window_ds.dims:
        raise ValueError("window_ds must have a time dimension")

    n_hours = int(window_ds.sizes["time"])
    timestamps = np.asarray(window_ds.time.values)
    hourly_values: list[float] = []
    resume_index = 0
    checkpoint = Path(hourly_checkpoint_path) if hourly_checkpoint_path is not None else None

    if checkpoint is not None and checkpoint.exists():
        cached = None
        try:
            cached = xr.open_dataarray(checkpoint).load()
            cached_values = np.asarray(cached.values, dtype=float)
            cached_times = np.asarray(cached.time.values)
            if (
                "time" in cached.dims
                and cached_values.ndim == 1
                and 0 < len(cached_values) <= n_hours
                and np.array_equal(cached_times, timestamps[: len(cached_values)])
            ):
                invalid = np.flatnonzero(~np.isfinite(cached_values))
                prefix = int(invalid[0]) if len(invalid) else len(cached_values)
                hourly_values = cached_values[:prefix].tolist()
                resume_index = len(hourly_values)
                if prefix < len(cached_values):
                    print(f"{progress_label}: recovering {prefix} finite hours before an invalid saved tail")
                print(f"{progress_label}: resuming {resume_index}/{n_hours} saved hourly fields")
            else:
                print(f"{progress_label}: ignoring incompatible hourly partial checkpoint")
        except Exception as error:  # pragma: no cover - defensive Drive recovery
            print(f"{progress_label}: ignoring unreadable hourly partial checkpoint ({type(error).__name__})")
        finally:
            if cached is not None:
                cached.close()

    weight_values = np.asarray(geometry.weights.values, dtype=float)
    weight_total = float(weight_values.sum())
    if not np.isfinite(weight_total) or weight_total <= 0:
        raise ValueError("Polygon weights must have a positive finite sum")
    polygon_cells = weight_values > 0

    def hourly_array():
        return xr.DataArray(
            np.asarray(hourly_values, dtype=float), coords={"time": timestamps[:len(hourly_values)]},
            dims="time", name="polygon_mean_divergence_925hpa",
            attrs={"units": "s^-1", "display_units": "1e-5 s^-1"})

    def save_progress():
        if checkpoint is not None and hourly_values:
            partial_hourly = hourly_array()
            partial_hourly.attrs["checkpoint"] = "resumable partial hourly series"
            write_dataarray_atomic(partial_hourly, checkpoint)
            print(f"{progress_label}: hourly partial checkpoint saved ({len(hourly_values)}/{n_hours})")

    dx_values = np.asarray(geometry.dx.magnitude)
    dy_values = np.asarray(geometry.dy.magnitude)
    for start in range(resume_index, n_hours, chunk_hours):
        stop = min(start + chunk_hours, n_hours)
        chunk = window_ds.isel(time=slice(start, stop)).load()
        n_chunk_hours = int(chunk.sizes["time"])
        # MetPy accepts an extra leading time dimension when dx/dy are expanded
        # to match it.  This is mathematically identical to calling divergence
        # once per hour, but removes hundreds of Python/MetPy dispatches.
        dx_chunk = np.broadcast_to(dx_values, (n_chunk_hours, *dx_values.shape)) * geometry.dx.units
        dy_chunk = np.broadcast_to(dy_values, (n_chunk_hours, *dy_values.shape)) * geometry.dy.units
        divergence = mpcalc.divergence(
            chunk["u_component_of_wind"].values * units("m/s"),
            chunk["v_component_of_wind"].values * units("m/s"),
            dx=dx_chunk,
            dy=dy_chunk,
            x_dim=-1,
            y_dim=-2,
        ).magnitude
        finite_polygon = np.isfinite(divergence[:, polygon_cells]).all(axis=1)
        # NaN * zero remains NaN. Cells outside the polygon are not part of its
        # mean; relevant derivative stencils are still checked by finite_polygon.
        weighted = np.where(polygon_cells[None, :, :], divergence, 0.) * weight_values[None, :, :]
        polygon_means = weighted.sum(axis=(-2, -1)) / weight_total
        invalid = np.flatnonzero(~finite_polygon | ~np.isfinite(polygon_means))
        if len(invalid):
            index = int(invalid[0])
            hourly_values.extend(np.asarray(polygon_means[:index], dtype=float).tolist())
            save_progress()  # Preserve the good hours even between regular save intervals.
            missing = {name: int((~np.isfinite(chunk[name].values[index])).sum())
                       for name in ("u_component_of_wind", "v_component_of_wind")}
            details = {
                "first_invalid_time_utc": pd.Timestamp(timestamps[start + index]).isoformat() + "Z",
                "cause": "nonfinite_wind_inputs" if any(missing.values()) else "nonfinite_divergence_from_finite_winds",
                "u_nonfinite_regional_cells": missing["u_component_of_wind"],
                "v_nonfinite_regional_cells": missing["v_component_of_wind"],
                "nonfinite_polygon_divergence_cells": int((~np.isfinite(divergence[index][polygon_cells])).sum()),
            }
            raise IncompleteDivergenceError(hourly_array(), details)
        hourly_values.extend(np.asarray(polygon_means, dtype=float).tolist())
        if stop % progress_every_hours == 0 or stop == n_hours:
            print(f"{progress_label}: {stop}/{n_hours} hourly fields complete")
        if checkpoint is not None and (stop % progress_every_hours == 0 or stop == n_hours):
            save_progress()
        del chunk, divergence, weighted, polygon_means, dx_chunk, dy_chunk
        gc.collect()

    hourly = xr.DataArray(
        np.asarray(hourly_values),
        coords={"time": timestamps},
        dims="time",
        name="polygon_mean_divergence_925hpa",
        attrs={"units": "s^-1", "display_units": "1e-5 s^-1"},
    )
    D_12h = compute_rolling_mean(hourly, window=12, min_periods=12, name="D_12h")
    return hourly, D_12h


def build_events_from_monthly_checkpoints(
    inventory: pd.DataFrame,
    *,
    required_months: Iterable[int] = (11, 12, 1, 2),
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Recalculate full-record thresholds and raw events from D12 files.

    The inventory must be complete.  Thresholds are computed afresh from all
    complete-season D12 values; no threshold from the established catalog is
    reused.
    """
    required_months = tuple(required_months)
    pending = inventory.loc[inventory["status"] != "complete"]
    if not pending.empty:
        raise RuntimeError(
            f"Historical D12 inventory is incomplete: {len(pending)} month(s) pending."
        )

    records: list[dict[str, object]] = []
    for row in inventory.sort_values(["season_year", "year", "month"]).itertuples(index=False):
        path = Path(row.checkpoint_path)
        if not path.exists():
            raise FileNotFoundError(f"Inventory lists a missing D12 checkpoint: {path}")
        D = xr.open_dataarray(path).load().dropna("time")
        records.append(
            {
                "season_year": int(row.season_year),
                "year": int(row.year),
                "month": int(row.month),
                "D": D,
            }
        )

    threshold_rows: list[dict[str, float | int]] = []
    thresholds: dict[int, float] = {}
    for month in required_months:
        D_month = xr.concat(
            [record["D"] for record in records if record["month"] == month], dim="time"
        ).sortby("time")
        mean_value, std_value, threshold = threshold_from_std(D_month, n_std=2.0)
        thresholds[month] = threshold
        threshold_rows.append(
            {
                "month": month,
                "D_mean_s-1": mean_value,
                "D_std_s-1": std_value,
                "threshold_s-1": threshold,
                "threshold_1e5_s-1": threshold * 1e5,
                "valid_D12_hours": int(D_month.sizes["time"]),
            }
        )

    event_frames: list[pd.DataFrame] = []
    for record in records:
        events = count_events_from_threshold(record["D"], thresholds[record["month"]]).copy()
        if events.empty:
            continue
        events["year"] = record["year"]
        events["month"] = record["month"]
        events["season_year"] = record["season_year"]
        events["detection_threshold_s-1"] = thresholds[record["month"]]
        events["detection_threshold_1e5_s-1"] = thresholds[record["month"]] * 1e5
        event_frames.append(events)

    events_df = (
        pd.concat(event_frames, ignore_index=True).sort_values("event_peak").reset_index(drop=True)
        if event_frames
        else pd.DataFrame()
    )
    thresholds_df = pd.DataFrame(threshold_rows).sort_values("month").reset_index(drop=True)
    return events_df, thresholds_df


def compare_merged_catalogs(
    established_catalog: pd.DataFrame,
    historical_catalog: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Match merged episodes by temporal overlap and report catalog changes.

    An established episode is considered retained if any historical-baseline
    merged episode overlaps its inclusive start--end interval.  This avoids
    requiring identical peak hours when a changed threshold broadens or
    shortens the same physical episode.
    """
    required = {"event_start", "event_end", "event_peak"}
    for name, catalog in (("established", established_catalog), ("historical", historical_catalog)):
        missing = required.difference(catalog.columns)
        if missing:
            raise ValueError(f"{name} catalog is missing required columns: {sorted(missing)}")

    old = established_catalog.copy().reset_index(drop=True)
    new = historical_catalog.copy().reset_index(drop=True)
    for frame in (old, new):
        for column in required:
            try:
                # Newer pandas defaults to one inferred format for the whole
                # column; ``mixed`` keeps date-only and timestamp values safe.
                frame[column] = pd.to_datetime(frame[column], format="mixed")
            except (TypeError, ValueError):
                # Retain compatibility with older pandas used by some Colab
                # runtimes, where ``format='mixed'`` is unavailable.
                frame[column] = pd.to_datetime(frame[column])
    old = old.sort_values("event_start").reset_index(drop=True)
    new = new.sort_values("event_start").reset_index(drop=True)

    rows: list[dict[str, object]] = []
    old_match_count = np.zeros(len(old), dtype=int)
    new_match_count = np.zeros(len(new), dtype=int)
    for old_index, old_event in old.iterrows():
        overlapping = new.loc[
            (new["event_start"] <= old_event["event_end"])
            & (new["event_end"] >= old_event["event_start"])
        ]
        for new_index, new_event in overlapping.iterrows():
            overlap_start = max(old_event["event_start"], new_event["event_start"])
            overlap_end = min(old_event["event_end"], new_event["event_end"])
            overlap_hours = int((overlap_end - overlap_start).total_seconds() / 3600) + 1
            rows.append(
                {
                    "comparison_status": "shared_temporal_overlap",
                    "established_event_id": old_index + 1,
                    "historical_event_id": new_index + 1,
                    "established_start": old_event["event_start"],
                    "established_end": old_event["event_end"],
                    "established_peak": old_event["event_peak"],
                    "historical_start": new_event["event_start"],
                    "historical_end": new_event["event_end"],
                    "historical_peak": new_event["event_peak"],
                    "overlap_hours": overlap_hours,
                    "peak_offset_hours": (new_event["event_peak"] - old_event["event_peak"]).total_seconds() / 3600,
                }
            )
            old_match_count[old_index] += 1
            new_match_count[new_index] += 1

    for old_index, old_event in old.iterrows():
        if old_match_count[old_index] == 0:
            rows.append(
                {
                    "comparison_status": "established_only_not_flagged_historical",
                    "established_event_id": old_index + 1,
                    "historical_event_id": pd.NA,
                    "established_start": old_event["event_start"],
                    "established_end": old_event["event_end"],
                    "established_peak": old_event["event_peak"],
                    "historical_start": pd.NaT,
                    "historical_end": pd.NaT,
                    "historical_peak": pd.NaT,
                    "overlap_hours": 0,
                    "peak_offset_hours": np.nan,
                }
            )

    for new_index, new_event in new.iterrows():
        if new_match_count[new_index] == 0:
            rows.append(
                {
                    "comparison_status": "historical_only_newly_flagged",
                    "established_event_id": pd.NA,
                    "historical_event_id": new_index + 1,
                    "established_start": pd.NaT,
                    "established_end": pd.NaT,
                    "established_peak": pd.NaT,
                    "historical_start": new_event["event_start"],
                    "historical_end": new_event["event_end"],
                    "historical_peak": new_event["event_peak"],
                    "overlap_hours": 0,
                    "peak_offset_hours": np.nan,
                }
            )

    comparison = pd.DataFrame(rows)
    summary = pd.DataFrame(
        [
            {"metric": "established_merged_episodes", "value": len(old)},
            {"metric": "historical_merged_episodes", "value": len(new)},
            {
                "metric": "established_episodes_retained_by_temporal_overlap",
                "value": int((old_match_count > 0).sum()),
            },
            {
                "metric": "established_episodes_not_flagged_historical",
                "value": int((old_match_count == 0).sum()),
            },
            {
                "metric": "historical_only_newly_flagged_episodes",
                "value": int((new_match_count == 0).sum()),
            },
        ]
    )
    return comparison, summary
